const express = require("express");
const path = require("path");
const { readJson } = require("../utils/jsonStore");

const router = express.Router();
const hotelsFile = path.join(__dirname, "..", "data", "hotels.json");

router.get("/", (req, res, next) => {
  try {
    const hotels = readJson(hotelsFile, []);
    res.json(hotels);
  } catch (error) {
    next(error);
  }
});

router.get("/:id", (req, res, next) => {
  try {
    const hotels = readJson(hotelsFile, []);
    const hotel = hotels.find((item) => item.id === Number(req.params.id));
    if (!hotel) return res.status(404).json({ error: "Hotel not found." });
    res.json(hotel);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
