const express = require("express");
const path = require("path");
const crypto = require("crypto");
const { readJson, writeJson } = require("../utils/jsonStore");

const router = express.Router();
const hotelsFile = path.join(__dirname, "..", "data", "hotels.json");
const bookingsFile = path.join(__dirname, "..", "..", "data", "bookings.json");

function validDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

router.post("/", (req, res, next) => {
  try {
    const {
      hotelId, name, phone, checkin, checkout, guests = 2, rooms = 1
    } = req.body || {};

    const hotels = readJson(hotelsFile, []);
    const hotel = hotels.find((item) => item.id === Number(hotelId));
    const cleanName = typeof name === "string" ? name.trim() : "";
    const cleanPhone = typeof phone === "string" ? phone.trim() : "";

    if (!hotel) return res.status(400).json({ error: "Please select a valid hotel." });
    if (!cleanName || cleanName.length > 100) {
      return res.status(400).json({ error: "Enter a name (up to 100 characters)." });
    }
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      return res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number." });
    }
    if (!validDate(checkin) || !validDate(checkout)) {
      return res.status(400).json({ error: "Enter valid check-in and check-out dates." });
    }

    const start = new Date(`${checkin}T00:00:00Z`);
    const end = new Date(`${checkout}T00:00:00Z`);
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);

    if (start < today || end <= start) {
      return res.status(400).json({ error: "Check-in cannot be in the past and check-out must be after check-in." });
    }

    const nights = (end - start) / 86400000;
    if (nights > 90) return res.status(400).json({ error: "Maximum demo stay is 90 nights." });

    const guestCount = Number(guests);
    const roomCount = Number(rooms);
    if (!Number.isInteger(guestCount) || guestCount < 1 || guestCount > 10) {
      return res.status(400).json({ error: "Guests must be between 1 and 10." });
    }
    if (!Number.isInteger(roomCount) || roomCount < 1 || roomCount > 5) {
      return res.status(400).json({ error: "Rooms must be between 1 and 5." });
    }

    const bookings = readJson(bookingsFile, []);
    const booking = {
      id: `RJP-${crypto.randomBytes(4).toString("hex").toUpperCase()}`,
      hotelId: hotel.id,
      hotel: hotel.name,
      name: cleanName,
      phone: cleanPhone,
      checkin,
      checkout,
      nights,
      guests: guestCount,
      rooms: roomCount,
      pricePerNight: hotel.pricePerNight,
      estimatedTotal: nights * roomCount * hotel.pricePerNight,
      status: "REQUESTED",
      createdAt: new Date().toISOString()
    };

    bookings.push(booking);
    writeJson(bookingsFile, bookings);

    res.status(201).json({
      message: "Booking request saved. This is not a confirmed hotel reservation.",
      booking
    });
  } catch (error) {
    next(error);
  }
});

router.get("/:id", (req, res, next) => {
  try {
    const bookings = readJson(bookingsFile, []);
    const booking = bookings.find((item) => item.id === req.params.id);
    if (!booking) return res.status(404).json({ error: "Booking reference not found." });
    // This demo endpoint is for local testing only. Add authentication before deployment.
    res.json({ booking });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
