const express = require("express");
const path = require("path");
const { ensureJsonFile } = require("./utils/jsonStore");
const hotelRoutes = require("./routes/hotels");
const bookingRoutes = require("./routes/bookings");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const rootDir = path.join(__dirname, "..");
const bookingsFile = path.join(rootDir, "data", "bookings.json");

ensureJsonFile(bookingsFile, []);

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  next();
});

app.use(express.static(path.join(rootDir, "public")));
app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api/hotels", hotelRoutes);
app.use("/api/bookings", bookingRoutes);

app.use((req, res) => res.status(404).json({ error: "Route not found." }));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`RajampetStay is running at http://localhost:${PORT}`);
  console.log("Demo mode: sample hotel data; bookings saved to data/bookings.json");
});
