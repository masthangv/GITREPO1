const fs = require("fs");
const path = require("path");

function ensureJsonFile(filePath, defaultValue = []) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultValue, null, 2) + "\n", "utf8");
  }
}

function readJson(filePath, fallback = []) {
  ensureJsonFile(filePath, fallback);
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    throw new Error(`Unable to parse JSON file ${filePath}: ${error.message}`);
  }
}

function writeJson(filePath, value) {
  ensureJsonFile(filePath);
  const tempPath = `${filePath}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(value, null, 2) + "\n", "utf8");
  fs.renameSync(tempPath, filePath);
}

module.exports = { ensureJsonFile, readJson, writeJson };
