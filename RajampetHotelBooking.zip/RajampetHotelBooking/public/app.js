const byId = (id) => document.getElementById(id);
const hotelList = byId("hotel-list");
const hotelSelect = byId("hotelId");
const bookingForm = byId("booking-form");
const resultBox = byId("booking-result");

function localDate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

const today = new Date();
const tomorrow = new Date(today);
tomorrow.setDate(tomorrow.getDate() + 1);
byId("checkin").min = localDate(today);
byId("checkout").min = localDate(today);
byId("checkin").value = localDate(today);
byId("checkout").value = localDate(tomorrow);
byId("checkout").min = localDate(tomorrow);

byId("checkin").addEventListener("change", () => {
  const next = new Date(`${byId("checkin").value}T12:00:00`);
  next.setDate(next.getDate() + 1);
  const minCheckout = localDate(next);
  byId("checkout").min = minCheckout;
  if (byId("checkout").value <= byId("checkin").value) {
    byId("checkout").value = minCheckout;
  }
});

function makeHotelCard(hotel) {
  const article = document.createElement("article");
  article.className = "hotel-card";

  const image = document.createElement("img");
  image.src = hotel.image;
  image.alt = `Sample hotel image for ${hotel.name}`;
  image.loading = "lazy";
  image.onerror = () => { image.style.display = "none"; };

  const content = document.createElement("div");
  content.className = "hotel-content";

  const title = document.createElement("h3");
  title.textContent = hotel.name;
  const location = document.createElement("p");
  location.className = "hotel-location";
  location.textContent = `📍 ${hotel.location}`;
  const description = document.createElement("p");
  description.className = "hotel-description";
  description.textContent = hotel.description;

  const amenities = document.createElement("div");
  amenities.className = "amenities";
  hotel.amenities.forEach((label) => {
    const tag = document.createElement("span");
    tag.className = "amenity";
    tag.textContent = label;
    amenities.appendChild(tag);
  });

  const price = document.createElement("p");
  price.className = "price";
  price.textContent = `₹${Number(hotel.pricePerNight).toLocaleString("en-IN")} `;
  const small = document.createElement("small");
  small.textContent = "/ night";
  price.appendChild(small);

  const button = document.createElement("button");
  button.type = "button";
  button.className = "select-button";
  button.textContent = "Select this hotel";
  button.addEventListener("click", () => {
    hotelSelect.value = String(hotel.id);
    byId("booking").scrollIntoView({ behavior: "smooth" });
  });

  content.append(title, location, description, amenities, price, button);
  article.append(image, content);
  return article;
}

async function loadHotels() {
  try {
    const response = await fetch("/api/hotels");
    if (!response.ok) throw new Error("Hotel list could not be loaded.");
    const hotels = await response.json();

    hotelList.replaceChildren();
    hotelSelect.replaceChildren();

    hotels.forEach((hotel) => {
      hotelList.appendChild(makeHotelCard(hotel));
      const option = document.createElement("option");
      option.value = String(hotel.id);
      option.textContent = `${hotel.name} — ₹${Number(hotel.pricePerNight).toLocaleString("en-IN")}/night`;
      hotelSelect.appendChild(option);
    });
    if (!hotels.length) hotelList.textContent = "No sample hotels configured.";
  } catch (error) {
    hotelList.textContent = error.message;
  }
}

bookingForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  resultBox.className = "result";
  resultBox.style.display = "block";
  resultBox.textContent = "Submitting request…";

  const payload = {
    hotelId: Number(hotelSelect.value),
    name: byId("name").value.trim(),
    phone: byId("phone").value.trim(),
    checkin: byId("checkin").value,
    checkout: byId("checkout").value,
    guests: Number(byId("guests").value),
    rooms: Number(byId("rooms").value)
  };

  try {
    const response = await fetch("/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to save request.");

    resultBox.className = "result success";
    resultBox.textContent =
      `Booking request saved.\nReference: ${data.booking.id}\n` +
      `Hotel: ${data.booking.hotel}\n` +
      `Stay: ${data.booking.nights} night(s)\n` +
      `Estimated sample total: ₹${Number(data.booking.estimatedTotal).toLocaleString("en-IN")}\n` +
      `Status: ${data.booking.status}\n\nThis is a request only, not a confirmed reservation.`;
    bookingForm.reset();
    byId("checkin").value = localDate(today);
    byId("checkout").value = localDate(tomorrow);
    byId("checkout").min = localDate(tomorrow);
  } catch (error) {
    resultBox.className = "result error";
    resultBox.textContent = error.message;
  }
});

loadHotels();
