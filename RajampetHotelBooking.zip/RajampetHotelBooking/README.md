# RajampetStay — Hotel Booking Demo

A complete starter project with a Node.js/Express backend, browser frontend, and JSON files for sample hotels and booking requests.

## Requirements
- Node.js 18 or newer
- npm (included with Node.js)

## Run on Windows PowerShell

```powershell
cd RajampetHotelBooking
npm install
npm start
```

Open http://localhost:3000

## Project structure

```text
RajampetHotelBooking/
├── package.json
├── README.md
├── .gitignore
├── data/
│   └── bookings.json
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
└── src/
    ├── server.js
    ├── routes/
    │   ├── hotels.js
    │   └── bookings.js
    ├── utils/
    │   └── jsonStore.js
    └── data/
        └── hotels.json
```

## API endpoints

- `GET /api/health` — server health
- `GET /api/hotels` — sample hotel list
- `GET /api/bookings/:id` — retrieve one booking by reference
- `POST /api/bookings` — create a booking request

Example request body:

```json
{
  "hotelId": 1,
  "name": "Guest Name",
  "phone": "9876543210",
  "checkin": "2026-11-01",
  "checkout": "2026-11-03",
  "guests": 2,
  "rooms": 1
}
```

## Important limitations

- Hotel names, locations and prices in `src/data/hotels.json` are demonstration data. Verify real properties and prices before publishing.
- Booking requests are saved in `data/bookings.json`. This is suitable for local demos, not a high-traffic production site.
- The app does not check live room inventory, collect payments, send SMS/WhatsApp messages, or confirm a real reservation.
- Before public deployment, add authentication for administrative functions, HTTPS, stronger persistence (such as MySQL/PostgreSQL), input/security hardening, backups, privacy notices, and real hotel availability integration.
- Keep `data/bookings.json` private; it contains personal booking details.

## Change sample hotels

Edit `src/data/hotels.json`, keeping each hotel `id` unique and `pricePerNight` numeric. Restart the server afterward.
